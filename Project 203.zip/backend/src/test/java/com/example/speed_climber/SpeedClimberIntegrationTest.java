package com.example.speed_climber;

import java.util.List;

import com.example.duel.Duel;
import com.example.duel.DuelRepository;
import com.example.tournament.Tournament;
import com.example.tournament.TournamentRepository;

@SpringBootTest
@RunWith(SpringRunner.class)
public class SpeedClimberIntegrationTest {
    @Autowired
    private DuelRepository duelRepository;

    @Autowired
    private TournamentRepository tournamentRepo;

    @Test
    public void testGetDuelsByTournament() {
        // Given
        Long tournamentId = 1L; 

        // When
        List<Duel> duels = duelRepository.getDuelsByTournament(tournamentId);

        // Then
        assertNotNull(duels);  
        assertFalse(duels.isEmpty());  
        assertEquals(tournamentId, duels.get(0).getTournament().getId()); 
    }

    

    @Test
    public void testGetTournamentByOrganizer() {
        // Given
        Long organizerId = 1L; 

        // When
        List<Tournament> tournaments = tournamentRepo.getTournamentByOrganizer(organizerId);

        // Then
        assertNotNull(tournaments); 
        assertFalse(tournaments.isEmpty()); 
        assertEquals(organizerId, tournaments.get(0).getOrganizer().getId()); 
    }
}
